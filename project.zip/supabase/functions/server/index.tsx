import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-d632b7fe/health", (c) => {
  return c.json({ status: "ok", ts: new Date().toISOString() });
});

// ── State-V Factory API Proxy ────────────────────────────────────────────────
// Der API-Key bleibt serverseitig (Env-Secret STATEV_API_KEY) und wird niemals
// an das Frontend ausgeliefert. Die Basis-URL ist per Secret STATEV_API_BASE
// überschreibbar, hat aber die offizielle State-V-URL als Default.

const STATEV_BASE = () =>
  (Deno.env.get("STATEV_API_BASE") || "https://api.statev.de/req").replace(/\/+$/, "");
const STATEV_KEY = () => Deno.env.get("STATEV_API_KEY") || "";

async function proxyStateV(c: any, path: string) {
  const base = STATEV_BASE();
  const key = STATEV_KEY();

  if (!key) {
    console.log(`State-V proxy error for ${path}: STATEV_API_KEY ist nicht gesetzt.`);
    return c.json(
      { error: "STATEV_API_KEY ist nicht konfiguriert." },
      500,
    );
  }

  // eingehende Query-Parameter (z.B. limit/offset) an Upstream weiterreichen
  const incoming = new URL(c.req.url).search;
  const url = `${base}${path}${incoming}`;

  try {
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${key}`,
        Accept: "application/json",
      },
    });

    const text = await res.text();
    if (!res.ok) {
      console.log(`State-V upstream ${res.status} für ${url}: ${text.slice(0, 500)}`);
      return c.json(
        { error: `State-V API antwortete mit Status ${res.status}`, upstream: text.slice(0, 1000) },
        502,
      );
    }

    let data: unknown;
    try {
      data = JSON.parse(text);
    } catch (parseErr) {
      console.log(`State-V JSON-Parsefehler für ${url}: ${parseErr}`);
      return c.json({ error: "State-V API lieferte kein gültiges JSON", raw: text.slice(0, 1000) }, 502);
    }

    return c.json(data);
  } catch (err) {
    console.log(`State-V Netzwerkfehler für ${url}: ${err}`);
    return c.json({ error: `State-V API nicht erreichbar: ${err instanceof Error ? err.message : String(err)}` }, 502);
  }
}

// Firmenliste (liefert die IDs für alle weiteren Endpunkte)
app.get("/make-server-d632b7fe/statev/factories", (c) => proxyStateV(c, "/factory/list/"));

// Endpunkte mit Firmen-/Factory-ID als Pfadparameter
app.get("/make-server-d632b7fe/statev/inventory/:id", (c) =>
  proxyStateV(c, `/factory/inventory/${encodeURIComponent(c.req.param("id"))}`));
app.get("/make-server-d632b7fe/statev/machines/:id", (c) =>
  proxyStateV(c, `/factory/machine/${encodeURIComponent(c.req.param("id"))}`));
app.get("/make-server-d632b7fe/statev/counter/:id", (c) =>
  proxyStateV(c, `/factory/counter/${encodeURIComponent(c.req.param("id"))}`));
app.get("/make-server-d632b7fe/statev/market/sell/:id", (c) =>
  proxyStateV(c, `/factory/marketoffers/sell/${encodeURIComponent(c.req.param("id"))}`));
app.get("/make-server-d632b7fe/statev/market/buy/:id", (c) =>
  proxyStateV(c, `/factory/marketoffers/buy/${encodeURIComponent(c.req.param("id"))}`));

// Verkaufslog: /factory/buyLog/{id}/{limit}/{skip} — limit ≤ 50, skip ≤ 1000
app.get("/make-server-d632b7fe/statev/buy-log/:id", (c) => {
  const id = encodeURIComponent(c.req.param("id"));
  const limit = Math.min(50, Math.max(1, parseInt(c.req.query("limit") || "50", 10) || 50));
  const skip = Math.min(1000, Math.max(0, parseInt(c.req.query("skip") || "0", 10) || 0));
  return proxyStateV(c, `/factory/buyLog/${id}/${limit}/${skip}`);
});

// ── VNET-Mail Verlauf (Supabase-KV) ──────────────────────────────────────────
// Protokolliert gesendete VNET-Mails als History. Der Versand selbst läuft
// clientseitig über die Embedded VAPI; hier wird nur der Verlauf gespeichert.

app.post("/make-server-d632b7fe/vnet/mail-log", async (c) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { receiverMail, msg, senderFactoryId, senderName, status, error } = body ?? {};

    if (!receiverMail || !msg) {
      return c.json(
        { error: "receiverMail und msg sind erforderlich zum Protokollieren der VNET-Mail." },
        400,
      );
    }

    const createdAt = new Date().toISOString();
    const id = crypto.randomUUID();
    const entry = {
      id,
      receiverMail: String(receiverMail),
      msg: String(msg),
      senderFactoryId: senderFactoryId ? String(senderFactoryId) : "",
      senderName: senderName ? String(senderName) : "",
      status: status === "failed" ? "failed" : "sent",
      error: error ? String(error) : undefined,
      createdAt,
    };

    await kv.set(`vnet_mail:${createdAt}:${id}`, entry);
    return c.json(entry);
  } catch (err) {
    console.log(`VNET mail-log POST Fehler: ${err instanceof Error ? err.message : String(err)}`);
    return c.json(
      { error: `Fehler beim Protokollieren der VNET-Mail: ${err instanceof Error ? err.message : String(err)}` },
      500,
    );
  }
});

app.get("/make-server-d632b7fe/vnet/mail-log", async (c) => {
  try {
    const limit = Math.min(500, Math.max(1, parseInt(c.req.query("limit") || "100", 10) || 100));
    const entries = (await kv.getByPrefix("vnet_mail:")) as any[];
    const sorted = (entries || [])
      .filter((e) => e && e.createdAt)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
    return c.json({ entries: sorted });
  } catch (err) {
    console.log(`VNET mail-log GET Fehler: ${err instanceof Error ? err.message : String(err)}`);
    return c.json(
      { error: `Fehler beim Laden des VNET-Mail-Verlaufs: ${err instanceof Error ? err.message : String(err)}` },
      500,
    );
  }
});

// ── Generischer App-State (Supabase-KV) ──────────────────────────────────────
// Spiegelt die persistierten Frontend-Stores (Aufträge, Rechnungen, Lager, …)
// in den KV-Store, damit die gesamte App geräteübergreifend synchron ist.
// Der Schlüssel entspricht dem jeweiligen persistKey des Stores.

app.get("/make-server-d632b7fe/state/:key", async (c) => {
  try {
    const key = c.req.param("key");
    const value = await kv.get(`state:${key}`);
    return c.json({ key, value: value ?? null });
  } catch (err) {
    console.log(`State GET Fehler: ${err instanceof Error ? err.message : String(err)}`);
    return c.json(
      { error: `Fehler beim Laden des App-States: ${err instanceof Error ? err.message : String(err)}` },
      500,
    );
  }
});

app.put("/make-server-d632b7fe/state/:key", async (c) => {
  try {
    const key = c.req.param("key");
    const body = await c.req.json().catch(() => ({}));
    if (!body || typeof body !== "object" || !("value" in body)) {
      return c.json({ error: "Body muss ein { value } Feld enthalten." }, 400);
    }
    await kv.set(`state:${key}`, (body as { value: unknown }).value);
    return c.json({ key, ok: true });
  } catch (err) {
    console.log(`State PUT Fehler: ${err instanceof Error ? err.message : String(err)}`);
    return c.json(
      { error: `Fehler beim Speichern des App-States: ${err instanceof Error ? err.message : String(err)}` },
      500,
    );
  }
});

Deno.serve(app.fetch);