// Zentrale Schmelz-/Produktionsrezepte – genutzt vom Schmelz-Kalkulator und
// vom Produktions-Rechner im Lager.
//
// `output` = Stückzahl pro Produktionsdurchlauf.
// `inputs` = feste Zutaten pro Durchlauf.
// `fuel: true` = zusätzlich ein wählbarer Brennstoff pro Durchlauf
//   (Kohlebrocken ×2 ODER Holzbrett ×1 ODER Öl ×2 ODER Holzspäne ×50).

export interface Ingredient { item: string; amount: number; }
export interface Recipe { output: number; inputs: Ingredient[]; fuel?: boolean; }

export const FUEL_OPTIONS: Record<string, Ingredient> = {
  Kohlebrocken: { item: 'Kohlebrocken', amount: 2 },
  Holzbrett: { item: 'Holzbrett', amount: 1 },
  'Öl': { item: 'Öl', amount: 2 },
  'Holzspäne': { item: 'Holzspäne', amount: 50 },
};

export const RECIPES: Record<string, Recipe> = {
  Eisenbarren: { output: 1, fuel: true, inputs: [{ item: 'Eisenerz', amount: 10 }] },
  Stahlbarren: { output: 1, fuel: true, inputs: [{ item: 'Eisenbarren', amount: 3 }] },
  Kupferbarren: { output: 1, fuel: true, inputs: [{ item: 'Kupfererz', amount: 10 }] },
  Silberbarren: { output: 1, fuel: true, inputs: [{ item: 'Silbererz', amount: 10 }] },
  Goldbarren: { output: 1, fuel: true, inputs: [{ item: 'Golderz', amount: 10 }] },
  Messingbarren: {
    output: 1,
    inputs: [
      { item: 'Kupferbarren', amount: 2 },
      { item: 'Zinkbarren', amount: 1 },
      { item: 'Kohlebrocken', amount: 2 },
    ],
  },
  Zinkbarren: { output: 1, inputs: [{ item: 'Sphalerit', amount: 12 }, { item: 'Kohlebrocken', amount: 2 }] },
  Titanbarren: { output: 1, inputs: [{ item: 'Titanerz', amount: 10 }, { item: 'Kohlebrocken', amount: 4 }] },
  'Sack Glasgranulat': { output: 8, fuel: true, inputs: [{ item: 'Kilo Quarzsand', amount: 80 }] },
  Ziegelstein: { output: 4, inputs: [{ item: 'Felsbrocken', amount: 5 }, { item: 'Kohlebrocken', amount: 2 }] },
  Nagel: { output: 15, inputs: [{ item: 'Eisenbarren', amount: 1 }, { item: 'Kohlebrocken', amount: 2 }] },
  Graphitfolie: { output: 2, inputs: [{ item: 'Graphit', amount: 3 }] },
  Lithiumfolie: { output: 2, inputs: [{ item: 'Lithium', amount: 3 }] },
};

export const PRODUCTS = Object.keys(RECIPES);

// Alle in Rezepten vorkommenden Materialien (Rohstoffe, Zwischenprodukte,
// Brennstoffe) – alphabetisch, dedupliziert. Grundlage für die EK-Preisliste.
export const ALL_MATERIALS: string[] = (() => {
  const set = new Set<string>();
  for (const recipe of Object.values(RECIPES)) {
    for (const ing of recipe.inputs) set.add(ing.item);
  }
  for (const fuel of Object.values(FUEL_OPTIONS)) set.add(fuel.item);
  return Array.from(set).sort((a, b) => a.localeCompare(b, 'de'));
})();

export interface ProducibleResult {
  product: string;
  runs: number;          // mögliche Produktionsdurchläufe
  producible: number;    // resultierende Stückzahl (runs × output)
  output: number;        // Ausbeute pro Durchlauf
  limiting: string[];    // Materialien, die den Durchsatz begrenzen
  fuelUsed?: string;     // gewählter (bester verfügbarer) Brennstoff
}

/**
 * Berechnet für ein Produkt, wie viel aus dem aktuellen Bestand direkt (eine
 * Rezept-Ebene) produziert werden kann. `stock` bildet Materialname → Menge ab.
 */
export function producibleFor(product: string, stock: Record<string, number>): ProducibleResult {
  const recipe = RECIPES[product];
  const limiting: string[] = [];
  let runs = Infinity;

  for (const ing of recipe.inputs) {
    const have = stock[ing.item] ?? 0;
    const possible = Math.floor(have / ing.amount);
    if (possible < runs) {
      runs = possible;
      limiting.length = 0;
      limiting.push(ing.item);
    } else if (possible === runs) {
      limiting.push(ing.item);
    }
  }

  let fuelUsed: string | undefined;
  if (recipe.fuel) {
    // Besten verfügbaren Brennstoff wählen (der die meisten Durchläufe erlaubt).
    let bestRuns = 0;
    let bestFuel: string | undefined;
    for (const [key, fuel] of Object.entries(FUEL_OPTIONS)) {
      const possible = Math.floor((stock[fuel.item] ?? 0) / fuel.amount);
      if (possible > bestRuns) {
        bestRuns = possible;
        bestFuel = key;
      }
    }
    fuelUsed = bestFuel ? FUEL_OPTIONS[bestFuel].item : undefined;
    if (bestRuns < runs) {
      runs = bestRuns;
      limiting.length = 0;
      limiting.push('Brennstoff');
    } else if (bestRuns === runs) {
      limiting.push('Brennstoff');
    }
  }

  if (!isFinite(runs) || runs < 0) runs = 0;
  return {
    product,
    runs,
    producible: runs * recipe.output,
    output: recipe.output,
    limiting,
    fuelUsed,
  };
}

const MAX_RUNS = 100_000; // Sicherheitskappe gegen Endlos-Simulation

/**
 * Maximal produzierbare Endmenge unter Berücksichtigung von Zwischenprodukten:
 * Rohstoffe werden bei Bedarf zu Zwischenstufen (z. B. Erz → Barren) verarbeitet.
 * Simuliert Durchlauf für Durchlauf greedy auf einer Bestandskopie und teilt sich
 * gemeinsame Rohstoffe (z. B. Kohle als Fixzutat *und* Brennstoff) korrekt auf.
 */
export function maxProducibleDeep(product: string, stock: Record<string, number>): ProducibleResult {
  const s: Record<string, number> = { ...stock };
  const recipe = RECIPES[product];
  let runs = 0;
  let limiting = '';

  // Verbraucht `bundles` Brennstoff-Einheiten aus verfügbaren Brennstoffen.
  const consumeFuel = (bundles: number): boolean => {
    let remaining = bundles;
    for (const fuel of Object.values(FUEL_OPTIONS)) {
      if (remaining <= 0) break;
      const avail = Math.floor((s[fuel.item] ?? 0) / fuel.amount);
      const take = Math.min(remaining, avail);
      s[fuel.item] = (s[fuel.item] ?? 0) - take * fuel.amount;
      remaining -= take;
    }
    return remaining <= 0;
  };

  // Stellt sicher, dass `qty` Einheiten von `item` im Bestand liegen und
  // verarbeitet dafür bei Bedarf Rohstoffe. Verbraucht keine Zieleinheiten.
  const ensure = (item: string, qty: number): boolean => {
    if ((s[item] ?? 0) >= qty) return true;
    const r = RECIPES[item];
    if (!r) {
      limiting = item; // Rohstoff nicht ausreichend vorhanden
      return false;
    }
    const deficit = qty - (s[item] ?? 0);
    const runsNeeded = Math.ceil(deficit / r.output);
    for (const ing of r.inputs) {
      const need = ing.amount * runsNeeded;
      if (!ensure(ing.item, need)) return false;
      s[ing.item] = (s[ing.item] ?? 0) - need;
    }
    if (r.fuel && !consumeFuel(runsNeeded)) {
      limiting = 'Brennstoff';
      return false;
    }
    s[item] = (s[item] ?? 0) + runsNeeded * r.output;
    return true;
  };

  while (runs < MAX_RUNS) {
    let ok = true;
    for (const ing of recipe.inputs) {
      if (!ensure(ing.item, ing.amount)) { ok = false; break; }
      s[ing.item] = (s[ing.item] ?? 0) - ing.amount;
    }
    if (ok && recipe.fuel && !consumeFuel(1)) {
      ok = false;
      limiting = 'Brennstoff';
    }
    if (!ok) break;
    runs++;
  }

  return {
    product,
    runs,
    producible: runs * recipe.output,
    output: recipe.output,
    limiting: limiting ? [limiting] : [],
  };
}
