import { Outlet, NavLink, useNavigate, useLocation } from "react-router";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  FileText,
  Calculator,
  Archive,
  HardDrive,
  Gavel,
  MessageSquare,
  Image as ImageIcon,
  Settings,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useOrderStore } from "./store/orderStore";
import { useSyncStore } from "./store/syncStore";

// ── Lokal-Status Anzeige ──────────────────────────────────────────────────────

function LocalIndicator() {
  const { deviceId } = useSyncStore();
  return (
    <div className="px-3 py-2 space-y-1.5">
      <div className="flex items-center gap-1.5 text-xs text-green-500">
        <span className="h-1.5 w-1.5 rounded-full bg-green-500" />
        <HardDrive className="h-3 w-3" />
        <span>Lokal gespeichert</span>
      </div>
      <div className="text-xs text-muted-foreground/50 font-mono">{deviceId}</div>
    </div>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────

export default function Root() {
  const navigate = useNavigate();
  const location = useLocation();
  const [syncTrigger, setSyncTrigger] = useState(0);
  const { autoArchiveCompleted, seedDefaultCustomers, seedDefaultItems } = useOrderStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Standard-Kunden einmalig anlegen
  useEffect(() => {
    seedDefaultCustomers();
  }, [seedDefaultCustomers]);

  // Standard-Artikel einmalig anlegen
  useEffect(() => {
    seedDefaultItems();
  }, [seedDefaultItems]);

  // Auto-archive completed orders older than 1 hour
  useEffect(() => {
    autoArchiveCompleted();
    const interval = setInterval(() => {
      autoArchiveCompleted();
    }, 60_000);
    return () => clearInterval(interval);
  }, [autoArchiveCompleted]);

  // Trigger UI-refresh on location change
  useEffect(() => {
    setSyncTrigger((prev) => prev + 1);
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navItems = [
    { to: "/",          icon: LayoutDashboard, label: "Dashboard", exact: true },
    { to: "/orders",    icon: ShoppingCart,    label: "Aufträge" },
    { to: "/inventory", icon: Package,         label: "Lager" },
    { to: "/invoices",  icon: FileText,        label: "Rechnungen" },
    { to: "/calculator",icon: Calculator,      label: "Kalkulator" },
    { to: "/auctions",  icon: Gavel,           label: "Auktionen" },
    { to: "/messenger", icon: MessageSquare,   label: "V-NET" },
    { to: "/pic",       icon: ImageIcon,       label: "PIC" },
    { to: "/archive",   icon: Archive,         label: "Archiv" },
    { to: "/settings",  icon: Settings,        label: "Einstellungen" },
  ];

  const handleNavigate = (path: string) => {
    const routeMap: Record<string, string> = {
      orders:    "/orders",
      invoices:  "/invoices",
      inventory: "/inventory",
    };
    navigate(routeMap[path] || path);
  };

  const activeLabel = navItems.find((i) =>
    i.exact ? location.pathname === i.to : location.pathname.startsWith(i.to) && i.to !== "/",
  )?.label ?? "Dashboard";

  const SidebarContent = () => (
    <>
      {/* Logo */}
      <div className="p-5 border-b border-sidebar-border">
        <h1 className="text-lg font-bold tracking-tight flex items-center gap-2.5">
          <span className="grid place-items-center h-9 w-9 rounded-xl bg-primary text-primary-foreground text-sm font-black shadow-[0_0_20px_-4px_var(--color-primary)]">
            SD
          </span>
          <span className="flex flex-col leading-none">
            <span className="text-foreground">SCHMELZDEPOT</span>
            <span className="text-[10px] font-medium text-muted-foreground mt-1 tracking-wide uppercase">
              Management System
            </span>
          </span>
        </h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.exact}
            className={({ isActive }) => `
              group relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all
              ${isActive
                ? "bg-primary/10 text-primary shadow-[inset_0_0_0_1px_rgba(255,128,0,0.25)]"
                : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }
            `}
          >
            {({ isActive }) => (
              <>
                <span
                  className={`absolute left-0 top-1/2 -translate-y-1/2 h-5 w-1 rounded-r-full bg-primary transition-all ${
                    isActive ? "opacity-100" : "opacity-0"
                  }`}
                />
                <item.icon className={`h-[18px] w-[18px] transition-colors ${isActive ? "text-primary" : ""}`} />
                {item.label}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-3 py-3 mx-1">
          <div className="h-9 w-9 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center text-primary font-bold text-xs shrink-0">
            SV
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium truncate">StateV Factory</p>
            <p className="text-xs text-muted-foreground truncate">Schmelzdepot</p>
          </div>
        </div>
        <div className="border-t border-sidebar-border/60">
          <LocalIndicator />
        </div>
      </div>
    </>
  );

  return (
    <div className="flex h-screen bg-background text-foreground font-sans antialiased overflow-hidden">
      {/* Ambient Orange Glow */}
      <div className="pointer-events-none fixed -top-40 -left-40 h-96 w-96 rounded-full bg-primary/10 blur-[120px]" />

      {/* Desktop Sidebar */}
      <aside className="w-64 bg-sidebar border-r border-sidebar-border flex-col hidden md:flex relative z-10">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="absolute left-0 top-0 h-full w-64 bg-sidebar border-r border-sidebar-border flex flex-col z-10">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative z-10">
        {/* Topbar */}
        <header className="h-16 border-b border-border bg-card/40 backdrop-blur-xl flex items-center justify-between px-4 md:px-6 shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 -ml-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 md:hidden"
              aria-label="Menü öffnen"
            >
              <div className="w-5 h-0.5 bg-current mb-1" />
              <div className="w-5 h-0.5 bg-current mb-1" />
              <div className="w-5 h-0.5 bg-current" />
            </button>
            <div className="flex flex-col leading-tight">
              <span className="text-[11px] uppercase tracking-widest text-primary font-semibold">
                Schmelzdepot
              </span>
              <h2 className="text-base font-semibold text-foreground">{activeLabel}</h2>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-border">
              <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
              Lokal gespeichert
            </span>
          </div>
        </header>

        <div
          className="flex-1 overflow-auto p-4 md:p-6"
          style={{
            fontFamily: "'Inter', system-ui, sans-serif",
            WebkitFontSmoothing: 'antialiased',
            MozOsxFontSmoothing: 'grayscale',
            textRendering: 'optimizeLegibility',
            fontFeatureSettings: '"cv02", "cv03", "cv04", "cv11"',
          }}
        >
          <div className="max-w-7xl mx-auto">
            <Outlet context={{ onNavigate: handleNavigate, syncTrigger }} />
          </div>
        </div>
      </main>
    </div>
  );
}
