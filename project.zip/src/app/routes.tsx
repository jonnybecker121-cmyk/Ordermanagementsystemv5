import { createBrowserRouter, useOutletContext, Navigate } from "react-router";
import Root from "./Root";
import Dashboard from "./components/Dashboard";
import OrderManager from "./components/OrderManager";
import InventoryManager from "./components/InventoryManager";
import InvoiceManager from "./components/InvoiceManager";
import PriceCalculator from "./components/PriceCalculator";
import ArchiveManager from "./components/ArchiveManager";
import AuctionManager from "./components/AuctionManager";
import MessengerView from "./components/MessengerView";
import PicView from "./components/PicView";
import OrderNumberSettings from "./components/OrderNumberSettings";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card";
import { Settings as SettingsIcon } from "lucide-react";

interface OutletCtx {
  onNavigate: (path: string) => void;
  syncTrigger: number;
}

function DashboardWrapper() {
  const context = useOutletContext<OutletCtx>();
  return <Dashboard onNavigate={context.onNavigate} syncTrigger={context.syncTrigger} />;
}

function InventoryManagerWrapper() {
  const context = useOutletContext<OutletCtx>();
  return <InventoryManager syncTrigger={context.syncTrigger} />;
}

function PriceCalculatorWrapper() {
  const context = useOutletContext<OutletCtx>();
  return <PriceCalculator syncTrigger={context.syncTrigger} />;
}

function ArchiveManagerWrapper() {
  const context = useOutletContext<OutletCtx>();
  return <ArchiveManager syncTrigger={context.syncTrigger} />;
}

function SettingsPage() {
  return (
    <Card className="max-w-3xl mx-auto bg-card border border-primary/20 shadow-lg shadow-primary/5">
      <CardHeader className="border-b border-primary/20 bg-card">
        <CardTitle className="flex items-center gap-2">
          <div className="p-1.5 bg-primary/90 rounded-md shadow-md shadow-primary/10">
            <SettingsIcon className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-foreground">Bestellnummern-Einstellungen</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <OrderNumberSettings />
      </CardContent>
    </Card>
  );
}

function NotFoundRedirect() {
  return <Navigate to="/" replace />;
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: DashboardWrapper },
      { path: "orders", Component: OrderManager },
      { path: "inventory", Component: InventoryManagerWrapper },
      { path: "messenger", Component: MessengerView },
      { path: "pic", Component: PicView },
      { path: "invoices", Component: InvoiceManager },
      { path: "calculator", Component: PriceCalculatorWrapper },
      { path: "archive", Component: ArchiveManagerWrapper },
      { path: "auctions", Component: AuctionManager },
      { path: "settings", Component: SettingsPage },
    ],
  },
  {
    path: "*",
    Component: NotFoundRedirect,
  }
]);
