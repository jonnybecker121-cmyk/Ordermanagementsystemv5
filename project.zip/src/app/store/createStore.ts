import { useSyncExternalStore } from "react";
import { loadBackendState, saveBackendState } from "../services/backendState";

/**
 * Minimaler zustand-artiger Store mit optionaler localStorage-Persistenz und
 * Supabase-Synchronisation. Bildet die `useStore()` / `useStore(selector)`
 * Hook-API nach, die von den importierten Komponenten erwartet wird.
 *
 * Ist ein `persistKey` gesetzt, wird der State
 *  1. sofort synchron aus localStorage geladen (Offline-Cache), und
 *  2. asynchron aus dem Supabase-KV-Store nachgeladen (Quelle der Wahrheit,
 *     geräteübergreifend). Jede Änderung wird debounced nach Supabase gepusht.
 * `sync: false` deaktiviert die Supabase-Spiegelung für einen Store.
 */
export function createStore<T extends object>(
  init: (
    set: (partial: Partial<T> | ((state: T) => Partial<T>)) => void,
    get: () => T,
  ) => T,
  options?: { persistKey?: string; sync?: boolean },
) {
  let state: T;
  const listeners = new Set<() => void>();

  const syncEnabled = Boolean(options?.persistKey) && options?.sync !== false;
  // Während der Hydration aus dem Backend soll `set` nicht zurück-pushen.
  let hydrating = false;
  let pushTimer: ReturnType<typeof setTimeout> | undefined;

  const persist = () => {
    if (options?.persistKey && typeof window !== "undefined") {
      try {
        window.localStorage.setItem(options.persistKey, JSON.stringify(state));
      } catch {
        /* Speicher voll oder nicht verfügbar – ignorieren */
      }
    }
  };

  const scheduleBackendPush = () => {
    if (!syncEnabled || hydrating || typeof window === "undefined") return;
    if (pushTimer) clearTimeout(pushTimer);
    pushTimer = setTimeout(() => {
      // Nur reine Datenfelder werden serialisiert (Funktionen fallen weg).
      const snapshot = JSON.parse(JSON.stringify(state));
      void saveBackendState(options!.persistKey!, snapshot);
    }, 600);
  };

  const set = (partial: Partial<T> | ((s: T) => Partial<T>)) => {
    const next = typeof partial === "function" ? (partial as (s: T) => Partial<T>)(state) : partial;
    state = { ...state, ...next };
    persist();
    scheduleBackendPush();
    listeners.forEach((l) => l());
  };

  const get = () => state;

  state = init(set, get);

  // Persistierte Daten laden (nur Datenfelder, keine Funktionen)
  if (options?.persistKey && typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(options.persistKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        state = { ...state, ...parsed };
      }
    } catch {
      /* defekte Daten ignorieren */
    }
  }

  // Aus Supabase nachladen (asynchron); Backend ist die Quelle der Wahrheit.
  if (syncEnabled && typeof window !== "undefined") {
    void loadBackendState<Partial<T>>(options!.persistKey!).then((remote) => {
      if (!remote || typeof remote !== "object") return;
      hydrating = true;
      set(remote);
      hydrating = false;
    });
  }

  const subscribe = (listener: () => void) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };

  function useStore(): T;
  function useStore<S>(selector: (state: T) => S): S;
  function useStore<S>(selector?: (state: T) => S) {
    return useSyncExternalStore(
      subscribe,
      () => (selector ? selector(state) : (state as unknown as S)),
      () => (selector ? selector(state) : (state as unknown as S)),
    );
  }

  return useStore;
}

export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
