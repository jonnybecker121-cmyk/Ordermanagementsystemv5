import { createStore, uid } from "./createStore";

interface SyncState {
  deviceId: string;
}

export const useSyncStore = createStore<SyncState>(
  () => ({
    deviceId: `SD-${uid().slice(0, 8).toUpperCase()}`,
  }),
  // Die deviceId muss pro Gerät eindeutig bleiben → nicht nach Supabase spiegeln.
  { persistKey: "sd_sync", sync: false },
);
