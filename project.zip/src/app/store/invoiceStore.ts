import { createStore, uid } from "./createStore";

export interface PaymentNote {
  id: string;
  title: string;
  content: string;
  isDefault: boolean;
}

interface InvoiceState {
  paymentNotes: PaymentNote[];

  addPaymentNote: (title: string, content: string) => void;
  updatePaymentNote: (id: string, title: string, content: string) => void;
  deletePaymentNote: (id: string) => void;
  setDefaultPaymentNote: (id: string) => void;
  getDefaultPaymentNote: () => PaymentNote | undefined;
}

// Ein einziger, neutraler Standard-Zahlungshinweis (keine erfundenen Geschäftsdaten).
const DEFAULT_NOTE: PaymentNote = {
  id: "default",
  title: "Standard",
  content:
    "Bitte überweisen Sie den Betrag innerhalb von 3 Tagen unter Angabe des Verwendungszwecks.",
  isDefault: true,
};

export const useInvoiceStore = createStore<InvoiceState>(
  (set, get) => ({
    paymentNotes: [DEFAULT_NOTE],

    addPaymentNote: (title, content) =>
      set({
        paymentNotes: [
          ...get().paymentNotes,
          { id: uid(), title, content, isDefault: false },
        ],
      }),

    updatePaymentNote: (id, title, content) =>
      set({
        paymentNotes: get().paymentNotes.map((n) =>
          n.id === id ? { ...n, title, content } : n,
        ),
      }),

    deletePaymentNote: (id) =>
      set({
        paymentNotes: get().paymentNotes.filter((n) => n.id !== id || n.isDefault),
      }),

    setDefaultPaymentNote: (id) =>
      set({
        paymentNotes: get().paymentNotes.map((n) => ({
          ...n,
          isDefault: n.id === id,
        })),
      }),

    getDefaultPaymentNote: () =>
      get().paymentNotes.find((n) => n.isDefault) || get().paymentNotes[0],
  }),
  { persistKey: "sd_invoice" },
);
