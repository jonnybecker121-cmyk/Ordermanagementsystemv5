import { createStore } from "./createStore";

// EK-Preise (Einkaufspreise) pro Material. Wird für die Kostenberechnung im
// Schmelz-Kalkulator genutzt und geräteübergreifend über Supabase gespiegelt.

interface MaterialPriceState {
  prices: Record<string, number>;       // EK-Preise je Material
  sellPrices: Record<string, number>;   // Verkaufspreise je Produkt
  setPrice: (material: string, price: number) => void;
  setSellPrice: (product: string, price: number) => void;
  clearPrices: () => void;
}

export const useMaterialPriceStore = createStore<MaterialPriceState>(
  (set, get) => ({
    prices: {},
    sellPrices: {},
    setPrice: (material, price) =>
      set({ prices: { ...get().prices, [material]: price } }),
    setSellPrice: (product, price) =>
      set({ sellPrices: { ...get().sellPrices, [product]: price } }),
    clearPrices: () => set({ prices: {}, sellPrices: {} }),
  }),
  { persistKey: "sd_material_prices" },
);
