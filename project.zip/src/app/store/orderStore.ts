import { createStore, uid } from "./createStore";

export type OrderStatus =
  | "Ausstehend"
  | "In Bearbeitung"
  | "Warten auf Zahlung"
  | "Gezahlt"
  | "Abgeschlossen";

export interface OrderItem {
  name: string;
  qty: number;
  price: number;
  disc: number; // Rabatt in %
}

export interface Order {
  id: string;
  number: string;
  ref?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  items: OrderItem[];
  taxRate: number;
  taxSign: "plus" | "minus";
  status: OrderStatus;
  createdAt: string;
  finishedAt?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
}

export interface Item {
  id: string;
  name: string;
  price: number;
}

interface OrderState {
  ordersOpen: Order[];
  ordersDone: Order[];
  ordersArchive: Order[];
  customers: Customer[];
  items: Item[];

  // Bestellnummern-Einstellungen
  orderPrefix: string;
  orderDigits: number;
  nextCounter: number;
  updateSettings: (s: { prefix: string; digits: number; counter: number }) => void;

  addOrder: (order: Omit<Order, "id" | "number" | "createdAt" | "status"> & Partial<Order>) => void;
  updateOrder: (id: string, patch: Partial<Order>) => void;
  moveToArchive: (id: string) => void;
  restoreFromArchive: (id: string) => void;
  deleteFromArchive: (id: string) => void;
  autoArchiveCompleted: () => void;

  customersSeeded: boolean;
  seedDefaultCustomers: () => void;

  itemsSeeded: boolean;
  seedDefaultItems: () => void;

  addCustomer: (c: Omit<Customer, "id">) => void;
  updateCustomer: (id: string, patch: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;

  addItem: (i: Omit<Item, "id">) => void;
  updateItem: (id: string, patch: Partial<Item>) => void;
  deleteItem: (id: string) => void;
}

const formatNumber = (prefix: string, digits: number, counter: number) =>
  `${prefix}-${String(counter).padStart(digits, "0")}`;

// Standard-Kunden, die beim ersten Start automatisch angelegt werden.
const DEFAULT_CUSTOMERS: Omit<Customer, "id">[] = [
  { name: "Nika_May", email: "Nika_May@statev.de", phone: "" },
  { name: "Titus_Gruber", email: "Titus_Gruber@statev.de", phone: "" },
  { name: "Jannis_Cain", email: "Jannis_Cain@statev.de", phone: "" },
  { name: "Eric_Ludwig", email: "Eric_Ludwig@statev.de", phone: "" },
  { name: "CarFactoryGambinoCo", email: "CarFactoryGambinoCo@statev.de", phone: "" },
  { name: "hyped", email: "hyped@statev.de", phone: "" },
  { name: "Nexus Corp", email: "Jannis_Cain@statev.de", phone: "" },
  { name: "Andre_Johnson", email: "Andre_Johnson@statev.de", phone: "" },
  { name: "PDM Motors", email: "Valea_Machiavelli@statev.de", phone: "" },
  { name: "Hope-Production", email: "Lucia_Lorenzi@statev.de", phone: "" },
  { name: "Robert_Finster", email: "Robert_Finster@statev.de", phone: "" },
  { name: "SYNERGY", email: "Andre_Johnson@statev.de", phone: "" },
];

// Standard-Artikel, die beim ersten Start automatisch angelegt werden.
const DEFAULT_ITEMS: Omit<Item, "id">[] = [
  { name: "Sack Glasgranulat", price: 10.5 },
  { name: "Stahlbarren", price: 56.0 },
  { name: "Eisenbarren", price: 15.0 },
  { name: "Kupferbarren", price: 23.0 },
  { name: "Silberbarren", price: 23.0 },
  { name: "Goldbarren", price: 55.0 },
];

export const useOrderStore = createStore<OrderState>(
  (set, get) => ({
    ordersOpen: [],
    ordersDone: [],
    ordersArchive: [],
    customers: [],
    items: [],

    orderPrefix: "SD",
    orderDigits: 4,
    nextCounter: 1000,

    customersSeeded: false,
    itemsSeeded: false,

    // Einmalig die Standard-Artikel anlegen. Bereits vorhandene Namen werden nicht dupliziert.
    seedDefaultItems: () => {
      const { itemsSeeded, items } = get();
      if (itemsSeeded) return;
      const existingNames = new Set(items.map((i) => i.name.toLowerCase()));
      const toAdd = DEFAULT_ITEMS.filter(
        (i) => !existingNames.has(i.name.toLowerCase()),
      ).map((i) => ({ id: uid(), ...i }));
      set({ items: [...items, ...toAdd], itemsSeeded: true });
    },

    // Einmalig die Standard-Kunden anlegen. Bereits vorhandene Namen werden nicht dupliziert.
    seedDefaultCustomers: () => {
      const { customersSeeded, customers } = get();
      if (customersSeeded) return;
      const existingNames = new Set(customers.map((c) => c.name.toLowerCase()));
      const toAdd = DEFAULT_CUSTOMERS.filter(
        (c) => !existingNames.has(c.name.toLowerCase()),
      ).map((c) => ({ id: uid(), ...c }));
      set({ customers: [...customers, ...toAdd], customersSeeded: true });
    },

    updateSettings: ({ prefix, digits, counter }) =>
      set({ orderPrefix: prefix, orderDigits: digits, nextCounter: counter }),

    addOrder: (order) => {
      const { ordersOpen, orderPrefix, orderDigits, nextCounter } = get();
      const newOrder: Order = {
        id: uid(),
        number: formatNumber(orderPrefix, orderDigits, nextCounter),
        createdAt: new Date().toISOString(),
        status: "Ausstehend",
        items: [],
        taxRate: 19,
        taxSign: "plus",
        customerName: "",
        customerEmail: "",
        ...order,
      };
      set({ ordersOpen: [newOrder, ...ordersOpen], nextCounter: nextCounter + 1 });
    },

    updateOrder: (id, patch) => {
      const { ordersOpen, ordersDone } = get();
      const applyTo = (list: Order[]) =>
        list.map((o) => (o.id === id ? { ...o, ...patch } : o));

      // Statuswechsel bestimmt, in welcher Liste der Auftrag lebt
      const target = patch.status;
      const isDoneStatus = target === "Gezahlt" || target === "Abgeschlossen";

      const found =
        ordersOpen.find((o) => o.id === id) || ordersDone.find((o) => o.id === id);
      if (!found) return;

      const updated: Order = {
        ...found,
        ...patch,
        finishedAt:
          isDoneStatus && !found.finishedAt ? new Date().toISOString() : found.finishedAt,
      };

      if (target && isDoneStatus) {
        set({
          ordersOpen: ordersOpen.filter((o) => o.id !== id),
          ordersDone: [updated, ...ordersDone.filter((o) => o.id !== id)],
        });
      } else if (target && !isDoneStatus) {
        set({
          ordersDone: ordersDone.filter((o) => o.id !== id),
          ordersOpen: [updated, ...ordersOpen.filter((o) => o.id !== id)],
        });
      } else {
        set({ ordersOpen: applyTo(ordersOpen), ordersDone: applyTo(ordersDone) });
      }
    },

    moveToArchive: (id) => {
      const { ordersDone, ordersArchive } = get();
      const order = ordersDone.find((o) => o.id === id);
      if (!order) return;
      set({
        ordersDone: ordersDone.filter((o) => o.id !== id),
        ordersArchive: [
          { ...order, finishedAt: order.finishedAt || new Date().toISOString() },
          ...ordersArchive,
        ],
      });
    },

    restoreFromArchive: (id) => {
      const { ordersDone, ordersArchive } = get();
      const order = ordersArchive.find((o) => o.id === id);
      if (!order) return;
      set({
        ordersArchive: ordersArchive.filter((o) => o.id !== id),
        ordersDone: [order, ...ordersDone],
      });
    },

    deleteFromArchive: (id) => {
      const { ordersArchive } = get();
      set({ ordersArchive: ordersArchive.filter((o) => o.id !== id) });
    },

    autoArchiveCompleted: () => {
      const { ordersDone, ordersArchive } = get();
      const cutoff = Date.now() - 3_600_000; // 1 Stunde
      const toArchive = ordersDone.filter(
        (o) =>
          o.status === "Abgeschlossen" &&
          new Date(o.finishedAt || o.createdAt).getTime() < cutoff,
      );
      if (toArchive.length === 0) return;
      const ids = new Set(toArchive.map((o) => o.id));
      set({
        ordersDone: ordersDone.filter((o) => !ids.has(o.id)),
        ordersArchive: [...toArchive, ...ordersArchive],
      });
    },

    addCustomer: (c) =>
      set({ customers: [...get().customers, { id: uid(), ...c }] }),
    updateCustomer: (id, patch) =>
      set({
        customers: get().customers.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      }),
    deleteCustomer: (id) =>
      set({ customers: get().customers.filter((c) => c.id !== id) }),

    addItem: (i) => set({ items: [...get().items, { id: uid(), ...i }] }),
    updateItem: (id, patch) =>
      set({ items: get().items.map((it) => (it.id === id ? { ...it, ...patch } : it)) }),
    deleteItem: (id) => set({ items: get().items.filter((it) => it.id !== id) }),
  }),
  { persistKey: "sd_orders_v3" },
);
