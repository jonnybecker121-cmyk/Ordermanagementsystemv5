import { createStore, uid } from "./createStore";

export interface InventoryLogEntry {
  id: string;
  timestamp: string;
  type: string;
  category: "item" | "maschine" | string;
  item: string;
  change: number;
  previousQuantity: number;
  newQuantity: number;
  details?: string;
}

export interface InventorySnapshot {
  timestamp: string;
  gold: { name: string; quantity: number }[];
  silver: { name: string; quantity: number }[];
  items: { name: string; quantity: number }[];
  machines: { name: string; quantity: number }[];
}

interface InventoryState {
  logs: InventoryLogEntry[];
  lastSnapshot: InventorySnapshot | null;

  addLog: (entry: Omit<InventoryLogEntry, "id" | "timestamp">) => void;
  clearLogs: () => void;
  updateSnapshot: (snapshot: InventorySnapshot) => void;
  setLogs: (entries: InventoryLogEntry[]) => void;
}

export const useInventoryStore = createStore<InventoryState>(
  (set, get) => ({
    logs: [],
    lastSnapshot: null,

    addLog: (entry) =>
      set({
        logs: [
          ...get().logs,
          { ...entry, id: uid(), timestamp: new Date().toISOString() },
        ].slice(-1000),
      }),

    clearLogs: () => set({ logs: [], lastSnapshot: null }),

    updateSnapshot: (snapshot) => set({ lastSnapshot: snapshot }),

    setLogs: (entries) => set({ logs: entries }),
  }),
  { persistKey: "sd_inventory" },
);
