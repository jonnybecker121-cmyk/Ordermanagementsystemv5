import { useEffect } from "react";
import { RouterProvider } from "react-router";
import { Toaster } from "sonner";
import { router } from "./routes";
import { ErrorBoundary } from "./components/ErrorBoundary";

export default function App() {
  // App läuft dauerhaft im Dark Mode – .dark-Klasse aktiviert auch alle
  // Tailwind `dark:`-Utilities in den Komponenten.
  useEffect(() => {
    document.documentElement.classList.add("dark");
    document.documentElement.style.colorScheme = "dark";
  }, []);

  return (
    <ErrorBoundary>
      <RouterProvider router={router} />
      <Toaster theme="dark" richColors position="top-right" />
    </ErrorBoundary>
  );
}
