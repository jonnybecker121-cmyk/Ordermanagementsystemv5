# Plan: VNET-Mail-Verlauf in Supabase protokollieren

## Context

Der VNET-Mail-Versand läuft bereits über die Embedded VAPI (`src/app/services/vnetVapi.ts` → `sendVnetMail()`), ausgelöst im Dialog in `src/app/components/MessengerView.tsx`. Der eigentliche Versand ist zwingend clientseitig (postMessage an das State-V-Fenster) und bleibt unverändert.

Der Nutzer möchte nun, dass **jede gesendete Mail im Backend protokolliert** wird – als Verlauf/History im vorhandenen Supabase-KV-Store (`kv_store_d632b7fe`). Ziel: nachvollziehbare Historie (wann, an wen, Nachricht, Erfolg/Fehler, Absender-Firma), abrufbar in der V-NET-Ansicht.

Die App ist Dreischicht: Frontend → Edge-Function (Hono, `supabase/functions/server/index.tsx`, Prefix `make-server-d632b7fe`) → KV. KV-Zugriff nur über die Helper in `supabase/functions/server/kv_store.tsx` (`set`, `getByPrefix`). Frontend ruft die Function mit `Authorization: Bearer ${publicAnonKey}` (aus `/utils/supabase/info`).

## Umzusetzen

### 1. Server-Routen (`supabase/functions/server/index.tsx`)
- `POST /make-server-d632b7fe/vnet/mail-log`
  - Body: `{ receiverMail, msg, senderFactoryId, senderName, status: "sent" | "failed", error? }`.
  - Validierung: `receiverMail` und `msg` erforderlich → sonst 400 mit aussagekräftiger Meldung.
  - Eintrag bauen: `{ id, receiverMail, msg, senderFactoryId, senderName, status, error, createdAt }` (id = `crypto.randomUUID()`, createdAt = ISO-String).
  - Speichern via `kv.set(`vnet_mail:${createdAt}:${id}`, entry)` (Zeitstempel im Key → sortierbarer Prefix). Bei Fehler `console.log` + 500 mit Detail.
  - Antwort: `c.json(entry)`.
- `GET /make-server-d632b7fe/vnet/mail-log`
  - `kv.getByPrefix("vnet_mail:")` → nach `createdAt` absteigend sortieren, optional `limit` (Query, Default 100) anwenden.
  - Antwort: `c.json({ entries })`. Fehler → 500 mit Detail + `console.log`.

### 2. Frontend-Service (`src/app/services/mailLog.ts`, neu)
- `import { projectId, publicAnonKey } from "/utils/supabase/info"`.
- Typ `MailLogEntry` (Felder wie oben).
- `logSentMail(entry): Promise<void>` → `POST` an die Route (Bearer publicAnonKey), Fehler werden geloggt aber **nicht** hochgeworfen (Protokollierung darf den UX-Fluss nicht brechen).
- `getMailLog(limit = 100): Promise<MailLogEntry[]>` → `GET`, gibt bei Fehler `[]` zurück und loggt.

### 3. MessengerView (`src/app/components/MessengerView.tsx`)
- Nach erfolgreichem `sendVnetMail(...)`: `logSentMail({ ..., status: "sent" })` aufrufen.
- Im `catch`-Zweig zusätzlich `logSentMail({ ..., status: "failed", error: message })` protokollieren (Best effort).
- `senderFactoryId = SENDER_FACTORY_ID`, `senderName` aus dem bereits geladenen State.
- Neue Verlaufs-Anzeige: kleiner „Verlauf"-Bereich (z. B. Liste im Dialog oder als zusätzlicher Tab/Panel), der beim Öffnen des Dialogs `getMailLog()` lädt und Empfänger, Zeit, Status (sent/failed) zeigt. Reuse: `Badge` für Status, bestehendes Card/List-Styling.

## Verifikation
- Dev-Server läuft bereits (kein `vite build`). Preview nutzen.
- VNET-Mail senden (mit gültigem Premium-Key) → Toast „gesendet"; Verlauf zeigt neuen Eintrag mit Status „sent".
- Absichtlich ohne Empfänger/Key senden → Fehler-Toast; Verlaufseintrag mit Status „failed" und Fehlermeldung (bzw. keine Server-Protokollierung bei reiner Client-Validierung – Log nur bei tatsächlichem Sendeversuch).
- Seite neu laden → Verlauf bleibt (aus Supabase-KV) erhalten.
- Netzwerk-Tab/Konsole: `POST`/`GET .../vnet/mail-log` liefern 200; keine Fehler.

---

# Plan (früher): State-V-API korrekt anbinden (echtes Schema)

## Context (aktueller Fix)

Der Nutzer hat die echte State-V-API-Doku geliefert. Das weicht vom bisher angenommenen Schema ab:

- **Basis-URL**: `https://api.statev.de/req` (Auth: `Authorization: Bearer <API-Key>`).
- Endpunkte brauchen eine **Firmen-/Factory-ID**, die man zuerst über `/factory/list/` holt:
  - `/factory/list/` → `[{ id, name, hash, isOpen, type, address }]`
  - `/factory/inventory/{id}` → `{ totalWeight, items:[{ item, amount, singleWeight, totalWeight, icon }] }`
  - `/factory/machine/{id}` (Singular!) → analog Inventory
  - `/factory/counter/{id}` → `{ totalWeight, items:[{ item, price, amount, singleWeight, totalWeight, icon }] }`
  - `/factory/marketoffers/sell/{id}` → `[{ item, pricePerUnit, totalPrice, availableAmount, createdAt, icon }]`
  - `/factory/marketoffers/buy/{id}` → wie sell, zusätzlich `listPrice`
  - `/factory/buyLog/{id}/{limit}/{skip}` → `[{ seller, buyer, price, discount, items:[{name,amount}], createdAt }]` (limit ≤ 50, skip ≤ 1000)

Bisher fehlerhaft: Proxy-Pfade ohne ID (`/factory/inventory` statt `/factory/inventory/{id}`), falsche Basis-URL-Konfiguration → 500 „STATEV_API_BASE ist nicht konfiguriert".

## Umzusetzen

1. **Proxy** (`supabase/functions/server/index.tsx`):
   - `STATEV_API_BASE` mit Default `https://api.statev.de/req` versehen (Secret optional überschreibbar) → kein „nicht konfiguriert"-Fehler mehr.
   - Routen an echtes Schema anpassen, ID als Pfadparameter durchreichen:
     `GET /statev/factories` → `/factory/list/`;
     `/statev/inventory/:id` → `/factory/inventory/{id}`;
     `/statev/machines/:id` → `/factory/machine/{id}`;
     `/statev/counter/:id` → `/factory/counter/{id}`;
     `/statev/market/sell/:id` → `/factory/marketoffers/sell/{id}`;
     `/statev/market/buy/:id` → `/factory/marketoffers/buy/{id}`;
     `/statev/buy-log/:id` → `/factory/buyLog/{id}/{limit}/{skip}` (limit/skip aus Query, geklemmt auf ≤50 / ≤1000).
2. **`statevApi.ts`**: Methoden auf ID-Parameter umstellen: `getFactories()`, `getFactoryInventory(id)`, `getFactoryMachines(id)`, `getFactoryCounter(id)`, Markt- und Log-Methoden mit `id`. `requestOrEmpty()` beibehalten. Mapper an reale Feldnamen (`item/amount/singleWeight/totalWeight`, `pricePerUnit/totalPrice/availableAmount`) anpassen; `totalWeight` der Antwort mitführen.
3. **Frontend (`InventoryManager.tsx` u.a.)**: zuerst `getFactories()`, Firmen-Auswahl (Select) anbieten, gewählte `factoryId` an alle weiteren Aufrufe geben. Ohne Auswahl bleibt die Ansicht leer.
4. **Verifikation**: Lager öffnen → Firma wählen → Inventory/Machines/Counter laden ohne Fehler; Markt-/Log-Ansichten zeigen echte Daten; Konsole frei.

---

# Plan (vorheriger Stand): Schmelzdepot — Upgrade auf erweiterte Rechnungs-, Lager- & Nummern-Funktionen

## Context

Die Grund-App (Schmelzdepot Business Management System) steht bereits: Sidebar + alle Ansichten, eigener `useSyncExternalStore`-Store, localStorage-Persistenz, keine Mock-Daten.

Der Nutzer hat anschließend fünf Referenzdateien unter `src/imports/` manuell bearbeitet und gesagt „da mit optiemieren" — d.h. die App soll auf den **reicheren Funktionsstand dieser Dateien** gehoben werden. Die Imports referenzieren mehrere Bausteine, die im aktuellen `src/app/` noch fehlen:

- `store/invoiceStore` → `useInvoiceStore`, Typ `PaymentNote` (Zahlungshinweis-Vorlagen)
- `store/inventoryStore` → `useInventoryStore`, Typ `InventoryLogEntry` (Bewegungs-Log + Snapshot)
- `components/Invoice.tsx` → druck-/exportierbare Rechnung mit `html2canvas` + Banner aus `assets/invoiceHeader`
- `services/statevApi` → neue Methoden `getFactoryInventory()`, `getFactoryMachines()`, Typ `Inventory`
- `store/orderStore` → neue Felder `orderPrefix`, `orderDigits`, `nextCounter` + Action `updateSettings`
- Banner-Asset: vom Nutzer als `src/imports/invoiceHeader.ts.txt` bereitgestellt (Base64-Data-URI, exportiert `invoiceHeaderSrc`)

Ziel: Diese Bausteine in `src/app/` nachbauen und die drei Ansichten (Rechnungen, Lager, Bestellnummern-Einstellungen) auf den Import-Stand bringen — unter Beibehaltung der bestehenden Architektur und der Vorgabe **keine Mock-Daten**.

## Rahmenbedingungen

- `src/imports/` bleibt **read-only** (Referenz). Alle neuen/geänderten Dateien liegen unter `src/app/`.
- Neue Stores nutzen die bestehende Factory `src/app/store/createStore.ts` (`createStore<T>(init,{persistKey})`, `uid()`), nicht zustand.
- Import-Pfade in `src/imports/*` lauten `../ui/...`, `../store/...`, `../services/...`, `./Invoice`. In `src/app/components/*` müssen sie `./ui/...`, `../store/...`, `../services/...`, `./Invoice` heißen — beim Portieren anpassen.
- „ohne moke daten" gilt weiter: `statevApi` liefert **leere** Inventory/Machines (echter Endpoint als Kommentar). Das Bewegungs-Log bleibt dadurch leer bis echte Daten kommen — Struktur ist aber vollständig vorhanden.

## Umzusetzen

### 1. Abhängigkeit
- `html2canvas` per pnpm installieren (für PNG-Export der Rechnung).

### 2. Banner-Asset
- `src/app/assets/invoiceHeader.ts` anlegen mit dem vom Nutzer gelieferten Inhalt aus `src/imports/invoiceHeader.ts.txt` (`export const invoiceHeaderSrc = 'data:image/...'`). Data-URI → html2canvas-tauglich, kein CORS.

### 3. Neue Stores (Muster wie `orderStore.ts`, mit `persistKey`)
- `src/app/store/invoiceStore.ts`
  - Typ `PaymentNote { id, title, content, isDefault }`
  - State `paymentNotes: PaymentNote[]` (leer initial; ein sinnvoller Standard-Hinweis als einziger vordefinierter Eintrag ist ok — keine „Fake-Geschäftsdaten")
  - Actions: `addPaymentNote(title,content)`, `updatePaymentNote(id,title,content)`, `deletePaymentNote(id)`, `setDefaultPaymentNote(id)`, `getDefaultPaymentNote()`
  - persistKey `sd_invoice`
- `src/app/store/inventoryStore.ts`
  - Typ `InventoryLogEntry { id, timestamp, type, category, item, change, previousQuantity, newQuantity, details }`
  - Snapshot-Typ `{ timestamp, gold, silver, items:{name,quantity}[], machines:{name,quantity}[] }`
  - State `logs: InventoryLogEntry[]`, `lastSnapshot | null`
  - Actions: `addLog(entry)` (ergänzt id+timestamp), `clearLogs()` (leert logs + snapshot), `updateSnapshot(s)`, `setLogs(entries)`
  - persistKey `sd_inventory`

### 4. `statevApi` erweitern (`src/app/services/statevApi.ts`)
- Typ `Inventory { items: { item:string; amount:number; singleWeight:number; totalWeight:number }[] }` exportieren.
- Methoden `getFactoryInventory(): Promise<Inventory>` und `getFactoryMachines(): Promise<Inventory>`, beide `return delay({ items: [] })` (leer — Kommentar: echten State-V-Endpoint einsetzen). Bestehende Markt-Methoden unverändert.

### 5. `orderStore` — Bestellnummern-Einstellungen (`src/app/store/orderStore.ts`)
- State ergänzen: `orderPrefix: string` (Default `"SD"`), `orderDigits: number` (Default `4`), `nextCounter: number` (Default `1000`).
- Action `updateSettings({ prefix, digits, counter })`.
- Nummerngenerierung umstellen: statt bisherigem `AUF-…` → `${orderPrefix}-${String(nextCounter).padStart(orderDigits,'0')}`; bei `addOrder` `nextCounter` inkrementieren (persistiert). persistKey ggf. auf `sd_orders_v3` erhöhen, damit alte Struktur nicht kollidiert.

### 6. Komponenten (nach `src/app/components/`)
- `Invoice.tsx` — aus `src/imports/Invoice.tsx` portieren: `html2canvas`-Import, Banner via `../assets/invoiceHeader`, PNG-Export, feste +5% Steuer-Logik, Layout unverändert. Nur Import-Pfad des Banners anpassen.
- `InvoiceManager.tsx` — durch die erweiterte Version aus `src/imports/InvoiceManager.tsx` ersetzen: Auftrag-laden-Select, Kunden-/Detailfelder, Positionsliste, Zahlungshinweis-Vorlagen (via `invoiceStore`), Entwurf-Autosave in localStorage, „Rechnung generieren" → rendert `Invoice`. Pfade auf `./ui/…`, `../store/…`, `./Invoice`.
- `InventoryManager.tsx` — durch die erweiterte Version aus `src/imports/InventoryManager.tsx` ersetzen: 3 Haupt-Tabs (Bestand / Bewegungs-Log / Statistiken), State-V-Sync + Snapshot-Diff-Tracking (`inventoryStore` + neue `statevApi`-Methoden), Auto-Reload 5 Min, Filter, Stats. Pfade anpassen. Prop `syncTrigger` wird bereits via `useOutletContext` durchgereicht.
- `OrderNumberSettings.tsx` — neu aus `src/imports/OrderNumberSettings.tsx` portieren (nutzt die neuen `orderStore`-Felder + `updateSettings`).
- `ItemManager-1.tsx` (einfache englische Variante) wird **ignoriert** — die bestehende deutsche `ItemManager.tsx` bleibt.

### 7. Routing/Shell
- `src/app/Root.tsx`: Sidebar-Eintrag „Einstellungen" (Icon `Settings`, Route `/settings`) ergänzen.
- `src/app/routes.tsx`: Route `/settings` → Wrapper, der `OrderNumberSettings` in einer Card rendert.

## Verifikation
- Dev-Server läuft bereits (kein `vite build`/`npm run dev`). Preview-Oberfläche nutzen.
- **Rechnungen**: Auftrag anlegen → in Rechnungen „Auftrag laden" übernimmt Daten → Positionen/Zahlungshinweis → „Rechnung generieren" zeigt `Invoice` mit Banner → „Exportieren als PNG" lädt Datei; Entwurf überlebt Reload (localStorage).
- **Zahlungshinweise**: Vorlage anlegen/bearbeiten/als Standard setzen → erscheint im Select.
- **Lager**: Tabs Bestand/Log/Statistiken rendern ohne Fehler; leere Zustände sichtbar (API leer); manueller „Laden"-Button ohne Crash.
- **Einstellungen**: Präfix/Ziffern/Nächste Nummer speichern → neuer Auftrag erhält Nummer im Format `PRÄFIX-0000`; Werte überleben Reload.
- Konsole frei von Fehlern (fehlende Module/Pfade); alle 10 Sidebar-Routen laden.
